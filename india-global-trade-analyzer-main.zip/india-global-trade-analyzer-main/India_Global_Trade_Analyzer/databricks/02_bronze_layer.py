from pyspark.sql.functions import *
from pyspark.sql.types import *

trade_schema = StructType([
    StructField("year", IntegerType(), True),
    StructField("frequency", StringType(), True),
    StructField("reporter_country", StringType(), True),
    StructField("partner_country", StringType(), True),
    StructField("product_code", StringType(), True),
    StructField("product_name", StringType(), True),
    StructField("indicator", StringType(), True),
    StructField("trade_value", DoubleType(), True)
])

bronze_df = (
    trade_df
    .filter(col("value").startswith("{"))
    .select(
        from_json(
            col("value"),
            trade_schema
        ).alias("data")
    )
    .select("data.*")
)

bronze_df.write.mode("overwrite").saveAsTable("bronze_trade")

print("Bronze Layer Created")