from pyspark.sql.functions import *

kafka_df = (
    spark.read
    .format("kafka")
    .option("kafka.bootstrap.servers", "<EXAMPLE/IP:PORT>")
    .option("subscribe", "trade_topic")
    .option("startingOffsets", "earliest")
    .option("endingOffsets", "latest")
    .load()
)

trade_df = kafka_df.selectExpr(
    "CAST(value AS STRING) as value"
)

print("Kafka Data Loaded")
