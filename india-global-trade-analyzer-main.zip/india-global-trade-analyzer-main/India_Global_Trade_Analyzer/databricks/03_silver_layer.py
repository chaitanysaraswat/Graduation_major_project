from pyspark.sql.functions import *

silver_df = (
    bronze_df
    .dropDuplicates()
    .dropna(
        subset=[
            "year",
            "reporter_country",
            "partner_country",
            "product_code"
        ]
    )
    .fillna({
        "trade_value":0
    })
)

silver_df.write \
    .mode("overwrite") \
    .saveAsTable("silver_trade")

silver_df.write.mode("overwrite").saveAsTable("silver_trade")

print("Silver Layer Created")

display(silver_df.limit(20))