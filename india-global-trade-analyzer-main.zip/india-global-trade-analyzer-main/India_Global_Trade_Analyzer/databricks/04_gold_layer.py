silver_df = spark.table("silver_trade")

print("Gold Layer Ready")


# 1. Top Trading Partners of India
from pyspark.sql.functions import *

top_partner_df = (
    silver_df
    .groupBy("partner_country")
    .agg(
        sum("trade_value").alias("total_trade_value")
    )
    .orderBy(desc("total_trade_value"))
)


# 2. Top Products Imported/Exported
top_product_df = (
    silver_df
    .groupBy("product_name")
    .agg(
        sum("trade_value").alias("total_trade_value")
    )
    .orderBy(desc("total_trade_value"))
)



# 3. Year-wise Trade Growth
yearly_trade_df = (
    silver_df
    .groupBy("year")
    .agg(
        sum("trade_value").alias("total_trade_value")
    )
    .orderBy("year")
)



# 4. Number of Products Traded by Country
country_product_df = (
    silver_df
    .groupBy("partner_country")
    .agg(
        countDistinct("product_code")
        .alias("unique_products")
    )
    .orderBy(desc("unique_products"))
)



# 5. Trade Distribution by Product Category
category_df = (
    silver_df
    .withColumn(
        "category",
        regexp_extract(
            col("product_code"),
            "_(.*)",
            1
        )
    )
    .groupBy("category")
    .agg(
        sum("trade_value")
        .alias("total_trade")
    )
    .orderBy(desc("total_trade"))
)



# 6. Most Valuable Trade Routes
route_df = (
    silver_df
    .groupBy(
        "reporter_country",
        "partner_country"
    )
    .agg(
        sum("trade_value")
        .alias("trade_value")
    )
    .orderBy(desc("trade_value"))
)




# 7. Average Trade Value per Product
avg_product_df = (
    silver_df
    .groupBy("product_name")
    .agg(
        avg("trade_value")
        .alias("avg_trade_value")
    )
    .orderBy(desc("avg_trade_value"))
)



# 8. KPI Cards
from pyspark.sql.functions import *

kpi_df = silver_df.agg(
    count("*").alias("total_transactions"),
    sum("trade_value").alias("total_trade_value"),
    countDistinct("partner_country").alias("partner_countries"),
    countDistinct("product_code").alias("products")
)


