import requests
import json
import time

from confluent_kafka import Producer

# ==========================================
# KAFKA CONFIG
# ==========================================

producer = Producer({

    'bootstrap.servers':
    'localhost:9092',

    'client.id':
    'trade-producer',

    'socket.timeout.ms':
    60000,

    'message.timeout.ms':
    60000,

    'request.timeout.ms':
    30000,

    'reconnect.backoff.ms':
    1000,

    'reconnect.backoff.max.ms':
    10000,

    'acks':
    '1',

    'queue.buffering.max.messages':
    100000,

    'queue.buffering.max.ms':
    100,

    'batch.num.messages':
    1000
})

TOPIC_NAME = "trade_topic"

# ==========================================
# INDICATORS
# ==========================================

INDICATORS = [
    "MPRT-TRD-VL",
    "XPRT-TRD-VL"
]

# ==========================================
# DELIVERY REPORT
# ==========================================

def delivery_report(err, msg):

    if err is not None:
        print(f"Delivery failed: {err}")

# ==========================================
# YEAR LOOP
# ==========================================

for year in range(2015, 2024):

    print(f"\n========== YEAR {year} ==========")

    for indicator in INDICATORS:

        print(f"\nFetching {indicator}")

        # ==========================================
        # API URL
        # ==========================================

        url = (
            "https://wits.worldbank.org/API/EXAMPLE/"
            "SDMX/V21/datasource/"
            "tradestats-trade/"
            f"reporter/ind/"
            f"year/{year}/"
            f"partner/all/"
            f"product/all/"
            f"indicator/{indicator}"
            f"?format=JSON"
        )

        response = requests.get(url)

        print("Status:", response.status_code)

        if response.status_code != 200:
            continue

        data = response.json()

        # ==========================================
        # DIMENSIONS
        # ==========================================

        dimensions = (
            data["structure"]
            ["dimensions"]
            ["series"]
        )

        freq_values = dimensions[0]["values"]
        reporter_values = dimensions[1]["values"]
        partner_values = dimensions[2]["values"]
        product_values = dimensions[3]["values"]
        indicator_values = dimensions[4]["values"]

        # ==========================================
        # SERIES DATA
        # ==========================================

        series_data = (
            data["dataSets"][0]["series"]
        )

        print(
            "Total Records:",
            len(series_data)
        )

        count = 0

        # ==========================================
        # PROCESS RECORDS
        # ==========================================

        for key, value in series_data.items():

            try:

                indexes = key.split(":")

                freq_index = int(indexes[0])
                reporter_index = int(indexes[1])
                partner_index = int(indexes[2])
                product_index = int(indexes[3])
                indicator_index = int(indexes[4])

                # ==========================================
                # DECODE DIMENSIONS
                # ==========================================

                frequency = (
                    freq_values[freq_index]["name"]
                )

                reporter_country = (
                    reporter_values[reporter_index]["name"]
                )

                partner_country = (
                    partner_values[partner_index]["name"]
                )

                product_code = (
                    product_values[product_index]["id"]
                )

                product_name = (
                    product_values[product_index]["name"]
                )

                indicator_name = (
                    indicator_values[indicator_index]["name"]
                )

                # ==========================================
                # TRADE VALUE
                # ==========================================

                observations = (
                    value["observations"]
                )

                trade_value = (
                    observations["0"][0]
                )

                # ==========================================
                # FINAL RECORD
                # ==========================================

                kafka_message = {

                    "year": year,

                    "frequency": frequency,

                    "reporter_country":
                    reporter_country,

                    "partner_country":
                    partner_country,

                    "product_code":
                    product_code,

                    "product_name":
                    product_name,

                    "indicator":
                    indicator_name,

                    "trade_value":
                    trade_value
                }

                # ==========================================
                # SEND TO KAFKA
                # ==========================================

                producer.produce(
                    TOPIC_NAME,
                    value=json.dumps(kafka_message),
                    callback=delivery_report
                )

                producer.poll(0)

                count += 1

                if count % 1000 == 0:

                    print(
                        f"Sent {count} records"
                    )

                # ==========================================
                # 100 RECORDS / SEC
                # ==========================================

                time.sleep(0.01)

            except Exception as e:

                print("Error:", e)

                continue

        print(
            f"Completed {indicator}"
        )

# ==========================================
# FLUSH
# ==========================================

producer.flush()

print("\nAll data streamed successfully.")
